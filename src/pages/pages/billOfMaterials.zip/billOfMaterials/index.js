import React from "react";
import BillMaterials from "../../components/billMaterials/BillMaterials";

const BillOfMaterials = () => {
  return (
    <div>
      <BillMaterials />
    </div>
  );
};

export default BillOfMaterials;
