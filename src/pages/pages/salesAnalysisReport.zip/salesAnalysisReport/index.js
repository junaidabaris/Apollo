import React from 'react'
import SalesAnalysis from '../../components/salesAnalysis/SalesAnalysis'

const SalesAnalysisReport = () => {
  return (
    <div><SalesAnalysis /></div>
  )
}

export default SalesAnalysisReport